package contactlessPayments;

import java.util.HashMap;
import java.util.Map;

public class SecurityEnhancements {
    private Map<String, String> cardPinDatabase;

    public SecurityEnhancements() {
        cardPinDatabase = new HashMap<>();
        // Sample data for testing
        cardPinDatabase.put("123456789012", "1234");
        cardPinDatabase.put("987654321098", "5678");
    }

    public boolean verifyPin(String cardNumber, String pin) {
        String storedPin = cardPinDatabase.get(cardNumber);
        return storedPin != null && storedPin.equals(pin);
    }
}