package contactlessPayments;

public class PaymentTerminal {
	private EMVProtocol emvProtocol;
    private SecurityEnhancements securityEnhancements;

    public PaymentTerminal() {
        emvProtocol = new EMVProtocol();
        securityEnhancements = new SecurityEnhancements();
    }

    public boolean authenticate(String cardNumber, String pin) {
        // Basic PIN authentication (in a real-world scenario, this should be securely hashed and stored)
        if (securityEnhancements.verifyPin(cardNumber, pin)) {
            return true;
        } else {
            return false;
        }
    }
}
