package contactlessPayments;

import java.util.Scanner; // Add this import

public class UserInterface {
    private PaymentTerminal terminal;

    public UserInterface() {
        terminal = new PaymentTerminal();
    }

    public void start() {
        Scanner scanner = new Scanner(System.in); // Ensure Scanner is imported

        System.out.println("Hello and Welcome to the Contactless Payment System");

        System.out.print("Enter your card number: ");
        String cardNumber = scanner.nextLine();

        System.out.print("Enter your PIN: ");
        String pin = scanner.nextLine();

        if (terminal.authenticate(cardNumber, pin)) {
            System.out.println("Authentication Successful! Proceeding With The Payment...");
            // Proceed with payment
        } else {
            System.out.println("Authentication Failed! Please Check Your Pin and Try Again.");
        }

        scanner.close();
    }
}