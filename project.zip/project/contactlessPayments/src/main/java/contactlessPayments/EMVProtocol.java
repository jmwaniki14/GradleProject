package contactlessPayments;

public class EMVProtocol {
    // Simulate the basic EMV protocol operations
    public boolean validateCard(String cardNumber) {
        // Validate card number (basic validation, in reality, more complex checks are required)
        return cardNumber.length() >= 12 && cardNumber.length() <= 19;
    }
}
